# minior

Package R facilitant l'intégration avec Minio à partir du client aws.s3