#' Intégration de R avec la plateforme de stockage Minio
#' 
#' minior permet de simplifier l'intégration de R avec
#'   le cloud de stockage open source Minio, disponible sur la plateforme innovation.   
#'   Il constitue une surcouche au client aws.s3, facilitant la communication avec Minio 
#'   (configuration, envoi/récupération de fichiers, listage des fichiers présents
#'   dans les buckets).
#' 
#' @section Bucket individuel et buckets partagés:
#'   Par défaut, l'ouverture d'une session R sur la plateforme innovation
#'   configure les variables d'environnement AWS S3 (ID, clé secrète, token de session)
#'   pour l'utilisation du bucket (coffre de stockage) individuel.
#'   Les fonctions de minior peuvent donc être directement utilisées pour la 
#'   communication avec le bucket personnel.
#'   En revanche, pour pouvoir accéder aux buckets partagés (i.e. accessibles
#'   dans le navigateur Minio à l'adresse http://minio.alpha.innovation.insee.eu),
#'   il est nécessaire de modifier les variables d'environnement. Pour cela, il suffit d'appeler la fonction
#'   \code{set_minio_shared} sans paramètre avant l'appel des autres fonctions de minior.
#' @docType package
#' @name minior
#' @author Éric Sigaud, Romain Avouac
NULL

