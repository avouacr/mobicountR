#' Configuration de Minio en mode partagé
#'
#' Par défaut, l'ouverture d'une session R sur la plateforme innovation
#' configure les variables d'environnement s3 (ID, clé secrète, token de session)
#' pour l'utilisation du bucket individuel (dont le nom correspond à l'idep).
#' 
#' Cette fonction modifie ces variables d'environnement pour permettre l'accès
#' aux buckets Minio partagés.
#'
#' @return Ne renvoie rien, se contente de positionner les variables
#' d'environnement nécessaire à l'accès à Minio.
#' @export
set_minio_shared <- function() {
  # Configuration de SSL
  httr::set_config(httr::config(ssl_verifypeer = 0L))
  # Variables d'environnement utilisées par la librairie aws.s3 pour accéder à Minio.
  Sys.setenv("AWS_ACCESS_KEY_ID" = "minio",
             "AWS_SECRET_ACCESS_KEY" = "minio123",
             "AWS_DEFAULT_REGION" = "us-east-1",
             "AWS_S3_ENDPOINT" = "minio.alpha.innovation.insee.eu",
             "LIBCURL_BUILD"="winssl")
  message("Le client AWS S3 est désormais configuré pour l'accès aux buckets partagés de Minio.
          Pour rétablir l'accès au bucket individuel, démarrer une nouvelle session R Studio.")
}