#' Dépôt d'un fichier sur Minio à partir du répertoire local
#'
#' Dépose un fichier présent dans le répertoire local de R
#' sur un bucket (espace de stockage) Minio.
#'
#' @param path_local Le chemin complet du fichier dans le répertoire local R.
#' @param filename Le nom du fichier sur Minio. Par défaut, le même nom que
#' le fichier initial.
#' @param dir_minio Le chemin du dossier dans lequel le fichier
#' doit être enregistré sur Minio.
#' @param bucket Le nom du bucket Minio à utiliser.
#'
#' @return TRUE si le dépôt s'est effectué avec succès. FALSE sinon.
#' @export
#' @examples
#' \dontrun{
#' put_local_file(
#' path_local = "~/tables/monfichierData.csv", 
#' dir_minio = "data/tables",
#' bucket = "aiee")
#' }
put_local_file <- function(path_local, 
                           filename = basename(path_local),
                           dir_minio, 
                           bucket) {
  
  # Connexion à Minio et dépôt du fichier
  path_minio <- paste(dir_minio, filename, sep = "/")
  result <- aws.s3::put_object(path_local, 
                               object = path_minio, 
                               bucket = bucket)
  return (result)
}


#' Dépôt d'un dataframe sous Minio avec transformation en fichier texte délimité.
#'
#' Dépose un dataframe sous Minio en le transformant en fichier délimité
#' au préalable.
#' La conversion en un fichier délimité s'appuie sur la fonction write_delim
#' du package readr.
#'
#' @param df Le dataframe R dont on souhaite envoyer le contenu sur Minio.
#' @param filename Nom du fichier à créer sur Minio (y compris l'extension).
#' @param dir_minio Le chemin du dossier dans lequel le fichier
#' doit être enregistré sur Minio.
#' @param bucket Le nom du bucket Minio à utiliser.
#' @param sep Charactère à utiliser comme séparateur lors de la création
#' du fichier délimité (défaut : ",").
#' @param col_names Le nom des colonnes du dataframe doit-il être écrit sur 
#' la première ligne du fichier ? (défaut : TRUE).
#' @param na Charactère à utiliser pour les valeurs manquantes. 
#' Par défaut, "" correspondant à une chaîne vide.
#' @return TRUE si l'export sur Minio a réussi.
#' @export
#' @examples
#' \dontrun{
#' put_df
#' (
#' df = monDataFrameR, 
#' file_name ="NomDeMonFichierSurMinio.csv",
#' dir_minio = "data/tables",
#' bucket = "aiee")
#' }
put_df <- function(df, 
                   filename, 
                   dir_minio,
                   bucket,  
                   sep = ",", 
                   col_names = TRUE,
                   na = "") {
  # Création d'une "rawConnection" pour y stocker le fichier csv, 
  # évite d'avoir à l'écrire sur le fileSystem
  raw <- rawConnection(raw(0), "r+")
  # Ecriture du contenu du csv dans la rawConnection
  readr::write_delim(df, 
              raw, 
              na = na,
              col_names = col_names,
              delim = sep
              )
  # Connexion à Minio et dépôt du fichier csv (utilisation de rawConnctionValue
  # pour récupérer le contenu ajouter à la RawConnexion)
  result <- put_local_file(rawConnectionValue(raw), 
                           dir_minio = dir_minio,
                           filename = filename, 
                           bucket = bucket
                           )
  # Fermeture de la connexion créée.
  close.connection(raw)
  return (result)
}


