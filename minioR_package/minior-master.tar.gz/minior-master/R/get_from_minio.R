#' Obtention de la liste des fichiers présents dans un bucket sur Minio
#'
#' Liste les différents fichiers présents dans un bucket donné sur Minio,
#' ou dans un sous-dossier de ce bucket.
#'
#'
#' @param bucket Nom du bucket sur Minio
#' @param dir_minio Chemin vers un sous-dossier du bucket dont on
#' souhaite lister les fichiers.
#' @param recursive Si TRUE, liste tous les fichiers et sous-fichiers
#' du bucket/dossier spécifié (défaut : FALSE).
#' @param path_complete Si TRUE, le vecteur en sortie contient les 
#' chemins complets jusqu'aux fichiers listés (défaut : TRUE).
#' @return Un vecteur contenant les chemins complets des fichiers présents 
#' dans le bucket/dossier spécifié.
#' @export
#' @examples
#' list_files(bucket = 'aiee', dir_minio ="out/matching_france")
list_files <- function(bucket, 
                       dir_minio = NULL, 
                       recursive = FALSE,
                       path_complete = TRUE) {

  all_res <- aws.s3::get_bucket(bucket = bucket)
  all_res <- unname(sapply(all_res, function(x) {return(x$Key)}))
  
  if (is.null(dir_minio)) {
    if (!recursive) {
      res <- all_res[is.na(stringr::str_extract(all_res, "/"))]
    } else {
      res <- all_res
    }
    
  } else {
    regex_sub <- paste0("^(", dir_minio, ")/")
    res_sub <- all_res[!is.na(stringr::str_extract(all_res, regex_sub))]
    if (!recursive) {
      nb_slash_dir <- stringr::str_count(dir_minio, "/")
      res <- res_sub[stringr::str_count(res_sub, "/") == nb_slash_dir + 1]
    } else {
      res <- res_sub
    }
  }
  if (!path_complete) {res <- basename(res)}
  return(res)
}

#' Récupération directe d'un fichier sur Minio
#'
#' Cette fonction permet de récupérer directement un fichier stocké sur Minio,
#' sans passer par une sauvegarde préalable en local.
#' 
#' @param path_minio Le chemin complet du fichier sur Minio.
#' @param bucket Le nom du bucket sur Minio.
#' @return Le contenu du fichier récupéré depuis Minio, renvoyé sous forme
#' d'une chaîne de charactères.
#' @export
#' @examples
#' \dontrun{
#' csv_string <- get_file("rp_IlleEtVilaine.csv", "aiee")
#' # Import en csv
#' df <- readr::read_csv(file = csv_string)
#' # Import en data.table
#' dt <- data.table::fread(text = csv_string)
#' }
#'
get_file <- function(path_minio, bucket){

  # Connexion et récupération de l'objet dans Minio.
  result <- aws.s3::get_object(object = path_minio, 
                               bucket = bucket,
                               verbose = T,
                               base_url = Sys.getenv("AWS_S3_ENDPOINT"),
                               use_https = F)
  # Conversion en chaîne de caractère du 'raw' résultat afin de rendre 
  # plus commode sa manipulation dans R.
  result <- rawToChar(result)
  return(result)
}


#' Récupération d'un fichier sur Minio en local
#' 
#' Cette fonction permet de récupérer un fichier sur Minio, et de le sauvegarder
#' dans le répertoire local de R.
#' Elle est notamment utile pour récupérer des fichiers zippés sur Minio,
#' qui ne peuvent pas être récupérés par la méthode directe (get_file).
#'
#' @param path_minio Chemin complet du fichier à récupérer sur Minio.
#' @param bucket Nom du bucket sur Minio.
#' @param ext_name Nom du fichier pour la sauvegarde en local.
#' Par défaut, même nom que sur Minio.
#' @param ext_dir Chemin du dossier dans lequel le fichier récupéré 
#' doit être sauvegardé.
#' @param uncompress Le fichier récupéré doit-il être décompressé ?
#' Ne fonctionne qu'avec les fichiers zip et tar (tar.gz, tar.bz..) pour
#' le moment.
#' @param remove L'archive compressée doit-elle être supprimée après
#' décompression ? TRUE par défaut.
#' Ignoré si \code{uncompress = FALSE}.
#' @export
#' @examples
#' \dontrun{
#' get_file_local(
#' path_minio = "geo-clt_rp_2017.tar.gz",
#' bucket = "aiee",
#' ext_dir = "~/data"
#' uncompress = TRUE)
#' }
get_file_local <- function(path_minio,
                           bucket = "aiee",
                           ext_name = basename(path_minio),
                           ext_dir,
                           uncompress = FALSE,
                           remove = TRUE
                            ){

  # Récupération du fichier sur Minio
  path_save <- paste(ext_dir, ext_name, sep = "/")
  aws.s3::save_object(object = path_minio, 
                      bucket = bucket, 
                      file = path_save)
  
  # Décompression du fichier si spécifié)
  extension <- tools::file_ext(path_save)
                               
  if(uncompress) {
    if (stringr::str_detect(extension, "tar")) {
      untar(path_save, exdir = ext_dir)
      if (remove) {file.remove(path_save)}
    }
    else if (extension == "zip") {
      unzip(path_save, exdir = ext_dir, junkpaths = TRUE)
      if (remove) {file.remove(path_save)}
    }
    else {stop("L'extension du fichier compressé n'est pas supportée.")}
  }
  return (TRUE)
}

